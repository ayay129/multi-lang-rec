# THIS FILE IS GENERATED FROM PADDLEPADDLE SETUP.PY
#
from . import npu # noqa: F401

__all__ = [  # noqa
    'npu',
]

