# THIS FILE IS GENERATED FROM PADDLEPADDLE SETUP.PY
#
import paddle
import os
for lib in os.listdir(os.getenv("CUSTOM_DEVICE_ROOT")):
    if lib.endswith(".so"):
        paddle.utils.cpp_extension.extension_utils.load_op_meta_info_and_register_op(
            lib
        )
from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def set_value_by_flags_and_idx_v2(pre_ids_all,input_ids,seq_lens_this_time,seq_lens_encoder,seq_lens_decoder,step_idx,stop_flags):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("set_value_by_flags_and_idx_v2", pre_ids_all,input_ids,seq_lens_this_time,seq_lens_encoder,seq_lens_decoder,step_idx,stop_flags)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'pre_ids_all' : pre_ids_all,'input_ids' : input_ids,'seq_lens_this_time' : seq_lens_this_time,'seq_lens_encoder' : seq_lens_encoder,'seq_lens_decoder' : seq_lens_decoder,'step_idx' : step_idx,'stop_flags' : stop_flags}
        outs = {}
        outs_list = ['pre_ids_all_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("set_value_by_flags_and_idx_v2", **locals())

        outs['pre_ids_all_out'] = pre_ids_all
        helper.append_op(type="set_value_by_flags_and_idx_v2", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def rebuild_padding_v2(tmp_out,cum_offsets,seq_lens_decoder,seq_lens_encoder,max_input_length):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("rebuild_padding_v2", tmp_out,cum_offsets,seq_lens_decoder,seq_lens_encoder,max_input_length)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'tmp_out' : tmp_out,'cum_offsets' : cum_offsets,'seq_lens_decoder' : seq_lens_decoder,'seq_lens_encoder' : seq_lens_encoder}
        outs = {}
        outs_list = ['out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("rebuild_padding_v2", **locals())

        outs['out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="rebuild_padding_v2", inputs=ins, outputs=outs, attrs={'max_input_length' : max_input_length})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def encode_rotary_qk(q,kv,rotary_emb,seq_lens,rotary_emb_dims,use_neox):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("encode_rotary_qk", q,kv,rotary_emb,seq_lens,rotary_emb_dims,use_neox)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'q' : q,'kv' : kv,'rotary_emb' : rotary_emb,'seq_lens' : seq_lens}
        outs = {}
        outs_list = ['rotary_q_out','rotary_kv_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("encode_rotary_qk", **locals())

        outs['rotary_q_out'] = q
        outs['rotary_kv_out'] = kv
        helper.append_op(type="encode_rotary_qk", inputs=ins, outputs=outs, attrs={'rotary_emb_dims' : rotary_emb_dims,'use_neox' : use_neox})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def set_stop_value_multi_ends_v2(topk_ids,stop_flags,seq_lens,end_ids,next_tokens):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("set_stop_value_multi_ends_v2", topk_ids,stop_flags,seq_lens,end_ids,next_tokens)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'topk_ids' : topk_ids,'stop_flags' : stop_flags,'seq_lens' : seq_lens,'end_ids' : end_ids,'next_tokens' : next_tokens}
        outs = {}
        outs_list = ['topk_ids_out','stop_flags_out','next_tokens_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("set_stop_value_multi_ends_v2", **locals())

        outs['topk_ids_out'] = topk_ids
        outs['stop_flags_out'] = stop_flags
        outs['next_tokens_out'] = next_tokens
        helper.append_op(type="set_stop_value_multi_ends_v2", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def transpose_remove_padding(input,seq_lens,padding_offset):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("transpose_remove_padding", input,seq_lens,padding_offset)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'input' : input,'seq_lens' : seq_lens,'padding_offset' : padding_offset}
        outs = {}
        outs_list = ['fmha_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("transpose_remove_padding", **locals())

        outs['fmha_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="transpose_remove_padding", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def fused_fapa_attention_op(qkv_out,cos,sin,cache_k,cache_v,seq_lens_encoder,seq_lens_decoder,block_tables,num_heads,kv_num_heads,head_dim,flag,max_seq_len,block_size,use_neox_style,use_alibi):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("fused_fapa_attention_op", qkv_out,cos,sin,cache_k,cache_v,seq_lens_encoder,seq_lens_decoder,block_tables,num_heads,kv_num_heads,head_dim,flag,max_seq_len,block_size,use_neox_style,use_alibi)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'qkv_out' : qkv_out,'cos' : cos,'sin' : sin,'cache_k' : cache_k,'cache_v' : cache_v,'seq_lens_encoder' : seq_lens_encoder,'seq_lens_decoder' : seq_lens_decoder,'block_tables' : block_tables}
        outs = {}
        outs_list = ['attn_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("fused_fapa_attention_op", **locals())

        outs['attn_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="fused_fapa_attention_op", inputs=ins, outputs=outs, attrs={'num_heads' : num_heads,'kv_num_heads' : kv_num_heads,'head_dim' : head_dim,'flag' : flag,'max_seq_len' : max_seq_len,'block_size' : block_size,'use_neox_style' : use_neox_style,'use_alibi' : use_alibi})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def step_paddle(stop_flags,seq_lens_this_time,ori_seq_lens_encoder,seq_lens_encoder,seq_lens_decoder,block_tables,encoder_block_lens,is_block_step,step_block_list,step_lens,recover_block_list,recover_lens,need_block_list,need_block_len,used_list_len,free_list,free_list_len,input_ids,pre_ids,step_idx,next_tokens,block_size,encoder_decoder_block_num,first_token_id):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("step_paddle", stop_flags,seq_lens_this_time,ori_seq_lens_encoder,seq_lens_encoder,seq_lens_decoder,block_tables,encoder_block_lens,is_block_step,step_block_list,step_lens,recover_block_list,recover_lens,need_block_list,need_block_len,used_list_len,free_list,free_list_len,input_ids,pre_ids,step_idx,next_tokens,block_size,encoder_decoder_block_num,first_token_id)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'stop_flags' : stop_flags,'seq_lens_this_time' : seq_lens_this_time,'ori_seq_lens_encoder' : ori_seq_lens_encoder,'seq_lens_encoder' : seq_lens_encoder,'seq_lens_decoder' : seq_lens_decoder,'block_tables' : block_tables,'encoder_block_lens' : encoder_block_lens,'is_block_step' : is_block_step,'step_block_list' : step_block_list,'step_lens' : step_lens,'recover_block_list' : recover_block_list,'recover_lens' : recover_lens,'need_block_list' : need_block_list,'need_block_len' : need_block_len,'used_list_len' : used_list_len,'free_list' : free_list,'free_list_len' : free_list_len,'input_ids' : input_ids,'pre_ids' : pre_ids,'step_idx' : step_idx,'next_tokens' : next_tokens}
        outs = {}
        outs_list = ['stop_flags_out','seq_lens_this_time_out','seq_lens_encoder_out','seq_lens_decoder_out','block_tables_out','encoder_block_lens_out','is_block_step_out','step_block_list_out','step_lens_out','recover_block_list_out','recover_lens_out','need_block_list_out','need_block_len_out','used_list_len_out','free_list_out','free_list_len_out','input_ids_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("step_paddle", **locals())

        outs['stop_flags_out'] = stop_flags
        outs['seq_lens_this_time_out'] = seq_lens_this_time
        outs['seq_lens_encoder_out'] = seq_lens_encoder
        outs['seq_lens_decoder_out'] = seq_lens_decoder
        outs['block_tables_out'] = block_tables
        outs['encoder_block_lens_out'] = encoder_block_lens
        outs['is_block_step_out'] = is_block_step
        outs['step_block_list_out'] = step_block_list
        outs['step_lens_out'] = step_lens
        outs['recover_block_list_out'] = recover_block_list
        outs['recover_lens_out'] = recover_lens
        outs['need_block_list_out'] = need_block_list
        outs['need_block_len_out'] = need_block_len
        outs['used_list_len_out'] = used_list_len
        outs['free_list_out'] = free_list
        outs['free_list_len_out'] = free_list_len
        outs['input_ids_out'] = input_ids
        helper.append_op(type="step_paddle", inputs=ins, outputs=outs, attrs={'block_size' : block_size,'encoder_decoder_block_num' : encoder_decoder_block_num,'first_token_id' : first_token_id})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def get_token_penalty_multi_scores(pre_ids,logits,penalty_scores,frequency_scores,presence_scores,cur_len,min_len,eos_token_id):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("get_token_penalty_multi_scores", pre_ids,logits,penalty_scores,frequency_scores,presence_scores,cur_len,min_len,eos_token_id)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'pre_ids' : pre_ids,'logits' : logits,'penalty_scores' : penalty_scores,'frequency_scores' : frequency_scores,'presence_scores' : presence_scores,'cur_len' : cur_len,'min_len' : min_len,'eos_token_id' : eos_token_id}
        outs = {}
        outs_list = ['logits_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("get_token_penalty_multi_scores", **locals())

        outs['logits_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="get_token_penalty_multi_scores", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def fused_blha_layer_op(hidden,norm_weight,qkv_weight,qkv_bias,qkv_deq_scale,out_linear_weight,out_linear_shift,out_linear_smooth,out_linear_deq_scale,ffn_norm_weight,ffn1_weight,ffn1_deq_scale,ffn2_weight,ffn2_shift,ffn2_smooth,ffn2_deq_scale,rope_emb,cache_k,cache_v,seq_lens_encoder,seq_lens_decoder,seq_lens_this_time,block_tables,flag,max_seq_len,block_size,epsilon,qkv_quant_scale,out_linear_quant_scale,ffn1_quant_scale,ffn2_quant_scale,trans_qkv,trans_out_linear,trans_ffn1,trans_ffn2,use_neox_style,use_alibi):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("fused_blha_layer_op", hidden,norm_weight,qkv_weight,qkv_bias,qkv_deq_scale,out_linear_weight,out_linear_shift,out_linear_smooth,out_linear_deq_scale,ffn_norm_weight,ffn1_weight,ffn1_deq_scale,ffn2_weight,ffn2_shift,ffn2_smooth,ffn2_deq_scale,rope_emb,cache_k,cache_v,seq_lens_encoder,seq_lens_decoder,seq_lens_this_time,block_tables,flag,max_seq_len,block_size,epsilon,qkv_quant_scale,out_linear_quant_scale,ffn1_quant_scale,ffn2_quant_scale,trans_qkv,trans_out_linear,trans_ffn1,trans_ffn2,use_neox_style,use_alibi)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'hidden' : hidden,'norm_weight' : norm_weight,'qkv_weight' : qkv_weight,'qkv_bias@OPTIONAL' : qkv_bias,'qkv_deq_scale@OPTIONAL' : qkv_deq_scale,'out_linear_weight' : out_linear_weight,'out_linear_shift@OPTIONAL' : out_linear_shift,'out_linear_smooth@OPTIONAL' : out_linear_smooth,'out_linear_deq_scale@OPTIONAL' : out_linear_deq_scale,'ffn_norm_weight' : ffn_norm_weight,'ffn1_weight' : ffn1_weight,'ffn1_deq_scale@OPTIONAL' : ffn1_deq_scale,'ffn2_weight' : ffn2_weight,'ffn2_shift@OPTIONAL' : ffn2_shift,'ffn2_smooth@OPTIONAL' : ffn2_smooth,'ffn2_deq_scale@OPTIONAL' : ffn2_deq_scale,'rope_emb' : rope_emb,'cache_k' : cache_k,'cache_v' : cache_v,'seq_lens_encoder' : seq_lens_encoder,'seq_lens_decoder' : seq_lens_decoder,'seq_lens_this_time' : seq_lens_this_time,'block_tables' : block_tables}
        outs = {}
        outs_list = ['hidden_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("fused_blha_layer_op", **locals())

        outs['hidden_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="fused_blha_layer_op", inputs=ins, outputs=outs, attrs={'flag' : flag,'max_seq_len' : max_seq_len,'block_size' : block_size,'epsilon' : epsilon,'qkv_quant_scale' : qkv_quant_scale,'out_linear_quant_scale' : out_linear_quant_scale,'ffn1_quant_scale' : ffn1_quant_scale,'ffn2_quant_scale' : ffn2_quant_scale,'trans_qkv' : trans_qkv,'trans_out_linear' : trans_out_linear,'trans_ffn1' : trans_ffn1,'trans_ffn2' : trans_ffn2,'use_neox_style' : use_neox_style,'use_alibi' : use_alibi})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def get_padding_offset_v2(input_ids,cum_offsets,token_num,seq_len):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("get_padding_offset_v2", input_ids,cum_offsets,token_num,seq_len)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'input_ids' : input_ids,'cum_offsets' : cum_offsets,'token_num' : token_num,'seq_len' : seq_len}
        outs = {}
        outs_list = ['x_remove_padding','cum_offsets_out','padding_offset','cu_seqlens_q','cu_seqlens_k']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("get_padding_offset_v2", **locals())

        outs['x_remove_padding'] = helper.create_variable(dtype='float32')
        outs['cum_offsets_out'] = helper.create_variable(dtype='float32')
        outs['padding_offset'] = helper.create_variable(dtype='float32')
        outs['cu_seqlens_q'] = helper.create_variable(dtype='float32')
        outs['cu_seqlens_k'] = helper.create_variable(dtype='float32')
        helper.append_op(type="get_padding_offset_v2", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def fused_allgather_mm(x1,x2,bias,hcom,world_size,gather_index,gather_output,comm_turn):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("fused_allgather_mm", x1,x2,bias,hcom,world_size,gather_index,gather_output,comm_turn)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x1' : x1,'x2' : x2,'bias@OPTIONAL' : bias}
        outs = {}
        outs_list = ['out_gather_mm','out_gather']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("fused_allgather_mm", **locals())

        outs['out_gather_mm'] = helper.create_variable(dtype='float32')
        outs['out_gather'] = helper.create_variable(dtype='float32')
        helper.append_op(type="fused_allgather_mm", inputs=ins, outputs=outs, attrs={'hcom' : hcom,'world_size' : world_size,'gather_index' : gather_index,'gather_output' : gather_output,'comm_turn' : comm_turn})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def step_paddle_op(stop_flags,seq_lens_this_time,ori_seq_lens_encoder,seq_lens_encoder,seq_lens_decoder,block_tables,encoder_block_lens,is_block_step,step_block_list,step_lens,recover_block_list,recover_lens,need_block_list,need_block_len,used_list_len,free_list,free_list_len,input_ids,pre_ids,step_idx,next_tokens,first_tokens_ids,block_size,encoder_decoder_block_num):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("step_paddle_op", stop_flags,seq_lens_this_time,ori_seq_lens_encoder,seq_lens_encoder,seq_lens_decoder,block_tables,encoder_block_lens,is_block_step,step_block_list,step_lens,recover_block_list,recover_lens,need_block_list,need_block_len,used_list_len,free_list,free_list_len,input_ids,pre_ids,step_idx,next_tokens,first_tokens_ids,block_size,encoder_decoder_block_num)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'stop_flags' : stop_flags,'seq_lens_this_time' : seq_lens_this_time,'ori_seq_lens_encoder' : ori_seq_lens_encoder,'seq_lens_encoder' : seq_lens_encoder,'seq_lens_decoder' : seq_lens_decoder,'block_tables' : block_tables,'encoder_block_lens' : encoder_block_lens,'is_block_step' : is_block_step,'step_block_list' : step_block_list,'step_lens' : step_lens,'recover_block_list' : recover_block_list,'recover_lens' : recover_lens,'need_block_list' : need_block_list,'need_block_len' : need_block_len,'used_list_len' : used_list_len,'free_list' : free_list,'free_list_len' : free_list_len,'input_ids' : input_ids,'pre_ids' : pre_ids,'step_idx' : step_idx,'next_tokens' : next_tokens,'first_tokens_ids' : first_tokens_ids}
        outs = {}
        outs_list = ['stop_flags_out','seq_lens_this_time_out','seq_lens_encoder_out','seq_lens_decoder_out','block_tables_out','encoder_block_lens_out','is_block_step_out','step_block_list_out','step_lens_out','recover_block_list_out','recover_lens_out','need_block_list_out','need_block_len_out','used_list_len_out','free_list_out','free_list_len_out','input_ids_out','first_token_ids_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("step_paddle_op", **locals())

        outs['stop_flags_out'] = stop_flags
        outs['seq_lens_this_time_out'] = seq_lens_this_time
        outs['seq_lens_encoder_out'] = seq_lens_encoder
        outs['seq_lens_decoder_out'] = seq_lens_decoder
        outs['block_tables_out'] = block_tables
        outs['encoder_block_lens_out'] = encoder_block_lens
        outs['is_block_step_out'] = is_block_step
        outs['step_block_list_out'] = step_block_list
        outs['step_lens_out'] = step_lens
        outs['recover_block_list_out'] = recover_block_list
        outs['recover_lens_out'] = recover_lens
        outs['need_block_list_out'] = need_block_list
        outs['need_block_len_out'] = need_block_len
        outs['used_list_len_out'] = used_list_len
        outs['free_list_out'] = free_list
        outs['free_list_len_out'] = free_list_len
        outs['input_ids_out'] = input_ids
        outs['first_token_ids_out'] = first_tokens_ids
        helper.append_op(type="step_paddle_op", inputs=ins, outputs=outs, attrs={'block_size' : block_size,'encoder_decoder_block_num' : encoder_decoder_block_num})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def fused_get_rotary_embedding(input_ids,position_ids,head_dim_shape_tensor,prompt_num,use_neox):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("fused_get_rotary_embedding", input_ids,position_ids,head_dim_shape_tensor,prompt_num,use_neox)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'input_ids' : input_ids,'position_ids' : position_ids,'head_dim_shape_tensor' : head_dim_shape_tensor}
        outs = {}
        outs_list = ['rotary_embedding']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("fused_get_rotary_embedding", **locals())

        outs['rotary_embedding'] = helper.create_variable(dtype='float32')
        helper.append_op(type="fused_get_rotary_embedding", inputs=ins, outputs=outs, attrs={'prompt_num' : prompt_num,'use_neox' : use_neox})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def fused_rope(query,cos,sin):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("fused_rope", query,cos,sin)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'query' : query,'cos' : cos,'sin' : sin}
        outs = {}
        outs_list = ['query_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("fused_rope", **locals())

        outs['query_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="fused_rope", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def fused_mm_reduce_scatter(x1,x2,bias,hcom,world_size,reduce_op,comm_turn):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("fused_mm_reduce_scatter", x1,x2,bias,hcom,world_size,reduce_op,comm_turn)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x1' : x1,'x2' : x2,'bias@OPTIONAL' : bias}
        outs = {}
        outs_list = ['result']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("fused_mm_reduce_scatter", **locals())

        outs['result'] = helper.create_variable(dtype='float32')
        helper.append_op(type="fused_mm_reduce_scatter", inputs=ins, outputs=outs, attrs={'hcom' : hcom,'world_size' : world_size,'reduce_op' : reduce_op,'comm_turn' : comm_turn})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def quant_int8(intput,shift,smooth,scale,round_type,max_bound,min_bound):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("quant_int8", intput,shift,smooth,scale,round_type,max_bound,min_bound)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'intput' : intput,'shift@OPTIONAL' : shift,'smooth@OPTIONAL' : smooth}
        outs = {}
        outs_list = ['output']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("quant_int8", **locals())

        outs['output'] = helper.create_variable(dtype='float32')
        helper.append_op(type="quant_int8", inputs=ins, outputs=outs, attrs={'scale' : scale,'round_type' : round_type,'max_bound' : max_bound,'min_bound' : min_bound})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def get_token_penalty_multi_scores_v2(pre_ids,logits,penalty_scores,frequency_scores,presence_scores,temperatures,bad_tokens,cur_len,min_len,eos_token_id):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("get_token_penalty_multi_scores_v2", pre_ids,logits,penalty_scores,frequency_scores,presence_scores,temperatures,bad_tokens,cur_len,min_len,eos_token_id)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'pre_ids' : pre_ids,'logits' : logits,'penalty_scores' : penalty_scores,'frequency_scores' : frequency_scores,'presence_scores' : presence_scores,'temperatures' : temperatures,'bad_tokens' : bad_tokens,'cur_len' : cur_len,'min_len' : min_len,'eos_token_id' : eos_token_id}
        outs = {}
        outs_list = ['logits_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("get_token_penalty_multi_scores_v2", **locals())

        outs['logits_out'] = logits
        helper.append_op(type="get_token_penalty_multi_scores_v2", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def fused_mm_allreduce(x1,x2,bias,hcom,reduce_op,comm_turn):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("fused_mm_allreduce", x1,x2,bias,hcom,reduce_op,comm_turn)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x1' : x1,'x2' : x2,'bias@OPTIONAL' : bias}
        outs = {}
        outs_list = ['result']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("fused_mm_allreduce", **locals())

        outs['result'] = helper.create_variable(dtype='float32')
        helper.append_op(type="fused_mm_allreduce", inputs=ins, outputs=outs, attrs={'hcom' : hcom,'reduce_op' : reduce_op,'comm_turn' : comm_turn})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def rms_norm_npu(x,gamma,epsilon):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("rms_norm_npu", x,gamma,epsilon)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x,'gamma' : gamma}
        outs = {}
        outs_list = ['y','rstd']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("rms_norm_npu", **locals())

        outs['y'] = helper.create_variable(dtype='float32')
        outs['rstd'] = helper.create_variable(dtype='float32')
        helper.append_op(type="rms_norm_npu", inputs=ins, outputs=outs, attrs={'epsilon' : epsilon})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def get_padding_offset(input_ids,cum_offsets,token_num,seq_len):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("get_padding_offset", input_ids,cum_offsets,token_num,seq_len)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'input_ids' : input_ids,'cum_offsets' : cum_offsets,'token_num' : token_num,'seq_len' : seq_len}
        outs = {}
        outs_list = ['x_remove_padding','cum_offsets_out','padding_offset']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("get_padding_offset", **locals())

        outs['x_remove_padding'] = helper.create_variable(dtype='float32')
        outs['cum_offsets_out'] = helper.create_variable(dtype='float32')
        outs['padding_offset'] = helper.create_variable(dtype='float32')
        helper.append_op(type="get_padding_offset", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def remove_padding(x,seqlen):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("remove_padding", x,seqlen)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x,'seqlen' : seqlen}
        outs = {}
        outs_list = ['x_remove_padding']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("remove_padding", **locals())

        outs['x_remove_padding'] = helper.create_variable(dtype='float32')
        helper.append_op(type="remove_padding", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def set_stop_value_multi_ends(topk_ids,stop_flags,end_ids,mode):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("set_stop_value_multi_ends", topk_ids,stop_flags,end_ids,mode)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'topk_ids' : topk_ids,'stop_flags' : stop_flags,'end_ids' : end_ids}
        outs = {}
        outs_list = ['topk_ids_out','stop_flags_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("set_stop_value_multi_ends", **locals())

        outs['topk_ids_out'] = helper.create_variable(dtype='float32')
        outs['stop_flags_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="set_stop_value_multi_ends", inputs=ins, outputs=outs, attrs={'mode' : mode})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def my_add_n(x,y,z):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("my_add_n", x,y,z)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'X' : x,'Y' : y,'Z' : z}
        outs = {}
        outs_list = ['Out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("my_add_n", **locals())

        outs['Out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="my_add_n", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def set_value_by_flags_and_idx(pre_ids_all,pre_ids_now,step_idx,stop_flags):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("set_value_by_flags_and_idx", pre_ids_all,pre_ids_now,step_idx,stop_flags)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'pre_ids_all' : pre_ids_all,'pre_ids_now' : pre_ids_now,'step_idx' : step_idx,'stop_flags' : stop_flags}
        outs = {}
        outs_list = ['stop_flags_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("set_value_by_flags_and_idx", **locals())

        outs['stop_flags_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="set_value_by_flags_and_idx", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def weight_only_linear_npu(x,weight,scale):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("weight_only_linear_npu", x,weight,scale)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x,'weight' : weight,'scale' : scale}
        outs = {}
        outs_list = ['output']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("weight_only_linear_npu", **locals())

        outs['output'] = helper.create_variable(dtype='float32')
        helper.append_op(type="weight_only_linear_npu", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def lm_head(x,norm_weight,linear_weight,epsilon,trans_weight,rank,nranks,root,ring_id):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("lm_head", x,norm_weight,linear_weight,epsilon,trans_weight,rank,nranks,root,ring_id)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x,'norm_weight' : norm_weight,'linear_weight' : linear_weight}
        outs = {}
        outs_list = ['out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("lm_head", **locals())

        outs['out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="lm_head", inputs=ins, outputs=outs, attrs={'epsilon' : epsilon,'trans_weight' : trans_weight,'rank' : rank,'nranks' : nranks,'root' : root,'ring_id' : ring_id})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def update_inputs(stop_flags,not_need_stop,seq_lens_this_time,seq_lens_encoder,seq_lens_decoder,input_ids,stop_nums,next_tokens,is_block_step):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("update_inputs", stop_flags,not_need_stop,seq_lens_this_time,seq_lens_encoder,seq_lens_decoder,input_ids,stop_nums,next_tokens,is_block_step)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'stop_flags' : stop_flags,'not_need_stop' : not_need_stop,'seq_lens_this_time' : seq_lens_this_time,'seq_lens_encoder' : seq_lens_encoder,'seq_lens_decoder' : seq_lens_decoder,'input_ids' : input_ids,'stop_nums' : stop_nums,'next_tokens' : next_tokens,'is_block_step' : is_block_step}
        outs = {}
        outs_list = ['not_need_stop_out','seq_lens_this_time_out','seq_lens_encoder_out','seq_lens_decoder_out','input_ids_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("update_inputs", **locals())

        outs['not_need_stop_out'] = not_need_stop
        outs['seq_lens_this_time_out'] = seq_lens_this_time
        outs['seq_lens_encoder_out'] = seq_lens_encoder
        outs['seq_lens_decoder_out'] = seq_lens_decoder
        outs['input_ids_out'] = input_ids
        helper.append_op(type="update_inputs", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def rebuild_padding(tmp_out,padding_offset,seq_lens,input_ids):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("rebuild_padding", tmp_out,padding_offset,seq_lens,input_ids)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'tmp_out' : tmp_out,'padding_offset' : padding_offset,'seq_lens' : seq_lens,'input_ids' : input_ids}
        outs = {}
        outs_list = ['out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("rebuild_padding", **locals())

        outs['out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="rebuild_padding", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def save_output(x,not_need_stop,rank_id):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("save_output", x,not_need_stop,rank_id)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x,'not_need_stop' : not_need_stop}
        outs = {}
        outs_list = ['x_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("save_output", **locals())

        outs['x_out'] = x
        helper.append_op(type="save_output", inputs=ins, outputs=outs, attrs={'rank_id' : rank_id})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def get_output(x,rank_id,wait_flag):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("get_output", x,rank_id,wait_flag)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x}
        outs = {}
        outs_list = ['x_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("get_output", **locals())

        outs['x_out'] = x
        helper.append_op(type="get_output", inputs=ins, outputs=outs, attrs={'rank_id' : rank_id,'wait_flag' : wait_flag})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def write_int8_cache_kv(input_k,input_v,cache_kv,k_quant_scales,v_quant_scales,q_dequant_scales,v_dequant_scales):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("write_int8_cache_kv", input_k,input_v,cache_kv,k_quant_scales,v_quant_scales,q_dequant_scales,v_dequant_scales)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'input_k' : input_k,'input_v' : input_v,'cache_kv' : cache_kv,'k_quant_scales' : k_quant_scales,'v_quant_scales' : v_quant_scales,'q_dequant_scales' : q_dequant_scales,'v_dequant_scales' : v_dequant_scales}
        outs = {}
        outs_list = ['cache_kv_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("write_int8_cache_kv", **locals())

        outs['cache_kv_out'] = cache_kv
        helper.append_op(type="write_int8_cache_kv", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def dequant_int8(intput,out_scale,dtype):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("dequant_int8", intput,out_scale,dtype)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'intput' : intput,'out_scale' : out_scale}
        outs = {}
        outs_list = ['output']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("dequant_int8", **locals())

        outs['output'] = helper.create_variable(dtype='float32')
        helper.append_op(type="dequant_int8", inputs=ins, outputs=outs, attrs={'dtype' : dtype})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def write_cache_kv(input_k,input_v,cache_kv,sequence_lengths):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("write_cache_kv", input_k,input_v,cache_kv,sequence_lengths)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'input_k' : input_k,'input_v' : input_v,'cache_kv' : cache_kv,'sequence_lengths' : sequence_lengths}
        outs = {}
        outs_list = ['cache_kv_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("write_cache_kv", **locals())

        outs['cache_kv_out'] = cache_kv
        helper.append_op(type="write_cache_kv", inputs=ins, outputs=outs, attrs={})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def save_with_output(x,batch_idx,step_idx,file_path,rank_id):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("save_with_output", x,batch_idx,step_idx,file_path,rank_id)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x,'batch_idx' : batch_idx,'step_idx' : step_idx}
        outs = {}
        outs_list = ['out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("save_with_output", **locals())

        outs['out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="save_with_output", inputs=ins, outputs=outs, attrs={'file_path' : file_path,'rank_id' : rank_id})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def flash_attention_npu(query,key,value,fixed_seed_offset,attn_mask,actual_seq_q_len,actual_seq_kv_len,dropout,causal,return_softmax,is_test,is_triangle_upper_mask,is_varlen):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("flash_attention_npu", query,key,value,fixed_seed_offset,attn_mask,actual_seq_q_len,actual_seq_kv_len,dropout,causal,return_softmax,is_test,is_triangle_upper_mask,is_varlen)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'query' : query,'key' : key,'value' : value,'fixed_seed_offset@OPTIONAL' : fixed_seed_offset,'attn_mask@OPTIONAL' : attn_mask,'actual_seq_q_len@OPTIONAL' : actual_seq_q_len,'actual_seq_kv_len@OPTIONAL' : actual_seq_kv_len}
        outs = {}
        outs_list = ['attention_score','softmax_max','softmax_sum','softmax_out','seed','offset','numel']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("flash_attention_npu", **locals())

        outs['attention_score'] = helper.create_variable(dtype='float32')
        outs['softmax_max'] = helper.create_variable(dtype='float32')
        outs['softmax_sum'] = helper.create_variable(dtype='float32')
        outs['softmax_out'] = helper.create_variable(dtype='float32')
        outs['seed'] = helper.create_variable(dtype='float32')
        outs['offset'] = helper.create_variable(dtype='float32')
        outs['numel'] = helper.create_variable(dtype='float32')
        helper.append_op(type="flash_attention_npu", inputs=ins, outputs=outs, attrs={'dropout' : dropout,'causal' : causal,'return_softmax' : return_softmax,'is_test' : is_test,'is_triangle_upper_mask' : is_triangle_upper_mask,'is_varlen' : is_varlen})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def qkv_transpose_split(qkv,padding_offset,seq_lens,input_ids,num_head,head_size):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("qkv_transpose_split", qkv,padding_offset,seq_lens,input_ids,num_head,head_size)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'qkv' : qkv,'padding_offset' : padding_offset,'seq_lens' : seq_lens,'input_ids' : input_ids}
        outs = {}
        outs_list = ['q_out','k_out','v_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("qkv_transpose_split", **locals())

        outs['q_out'] = helper.create_variable(dtype='float32')
        outs['k_out'] = helper.create_variable(dtype='float32')
        outs['v_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="qkv_transpose_split", inputs=ins, outputs=outs, attrs={'num_head' : num_head,'head_size' : head_size})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res


from paddle import _C_ops
from paddle.framework import in_dynamic_or_pir_mode
from paddle.base.layer_helper import LayerHelper
from paddle.jit.marker import unified

@unified
def atb_rms_norm(x,norm_weight,residual,epsilon):
    # The output variable's dtype use default value 'float32',
    # and the actual dtype of output variable will be inferred in runtime.
    if in_dynamic_or_pir_mode():
        outs = _C_ops._run_custom_op("atb_rms_norm", x,norm_weight,residual,epsilon)
        res = []
        start_idx = 0
        res.append(outs[start_idx])
        start_idx += 1
        res.append(outs[start_idx])
        start_idx += 1
        return res[0] if len(res)==1 else res
    else:
        ins = {}
        ins_map = {'x' : x,'norm_weight' : norm_weight,'residual@OPTIONAL' : residual}
        outs = {}
        outs_list = ['out','residual_out']
        for key, value in ins_map.items():
            # handle optional inputs
            if value is not None:
                ins[key] = value
        helper = LayerHelper("atb_rms_norm", **locals())

        outs['out'] = helper.create_variable(dtype='float32')
        outs['residual_out'] = helper.create_variable(dtype='float32')
        helper.append_op(type="atb_rms_norm", inputs=ins, outputs=outs, attrs={'epsilon' : epsilon})
        res = [outs[out_name] if out_name in outs.keys() else None for out_name in outs_list]
        return res[0] if len(res)==1 else res
