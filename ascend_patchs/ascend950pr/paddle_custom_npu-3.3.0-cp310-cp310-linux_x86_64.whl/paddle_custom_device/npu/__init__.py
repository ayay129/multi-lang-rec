# THIS FILE IS GENERATED FROM PADDLEPADDLE SETUP.PY
#
from .ops import *

full_version  = '3.3.0'
cann_version  = '8.0.0'
git_commit_id = '8df1985b9cfc6ab7c9b5f720939213c64c5fc48f'
custom_op_git_commit_id = '8df1985b9cfc6ab7c9b5f720939213c64c5fc48f'

__all__ = ['version']

def version():
    """Get the version info of paddle custom npu

    Returns:
        version: version of paddle custom npu
        commit: the commit id of paddle custom npu
        cann: the cann version of paddle custom npu

    Examples:
        .. code-block:: python

            import paddle_custom_device

            paddle_custom_device.npu.version()
            # version: 2.5.0
            # commit: b1539a921dbabf708807ebedb2671fa7bd3fd2f9
            # cann: 6.0.1
    """
    print('version:', full_version)
    print('commit:', git_commit_id)
    print('custom_op commit:', custom_op_git_commit_id)
    print('cann:', cann_version)
    return {'version': full_version, 'commit': git_commit_id, 'custom_op commit': custom_op_git_commit_id, 'cann': cann_version}
